const express = require("express");
const app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({
  extended: true
}));

var arr, arr1;

app.get("/",function(request,response){
  response.sendFile(__dirname + "/jaya.html");
});

app.post("/",function(request,response){
  arr=request.body;
  response.json({msg:"hello"});
});

app.post("/getdata",function(request,response){
  response.send(arr.data);
});

app.post("/1",function(request,response){
  arr1=request.body;
  response.json({msg:"hello"});
});

app.post("/getdata1",function(request,response){
  response.send(arr1.data);
});

app.listen(3000,function(){
  console.log("Server listening at 3000...");
})
